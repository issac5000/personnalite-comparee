export { default } from './text.js';
